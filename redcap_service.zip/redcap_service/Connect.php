<?php

function Connect()
{
	$hostname = "localhost";
	$username = "redcap_owner";
	$password = "redcap_owner";
	// Return connected PDO.
	$dbh = new PDO("mysql:host=$hostname;dbname=redcap_edc", $username, $password);
	return $dbh;
}
